/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {},
}

module.exports = nextConfig
